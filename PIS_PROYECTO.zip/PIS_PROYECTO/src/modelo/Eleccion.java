/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Eleccion {
    private Integer id_eleccion;
//    private Integer id_voto;
    private Integer id_papeleta;

    public Integer getId_Eleccion() {
        return id_eleccion;
    }

    public void setId_Eleccion(Integer eleccion) {
        this.id_eleccion = eleccion;
    }

    public Integer getId_papeleta() {
        return id_papeleta;
    }

    public void setId_papeleta(Integer id_papeleta) {
        this.id_papeleta = id_papeleta;
    }
}
